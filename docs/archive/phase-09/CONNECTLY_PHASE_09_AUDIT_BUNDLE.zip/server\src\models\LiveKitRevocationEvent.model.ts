import mongoose, { Schema, Document, Model, Types } from 'mongoose';

export type LiveKitRevocationKind =
  | 'PARTICIPANT_REMOVED'
  | 'PARTICIPANT_LEFT'
  | 'MEETING_ENDED';

/**
 * Global monotonic sequence counter stored in MongoDB so multi-instance
 * revocation events have a clock-skew-independent total order (`seq = 1, 2, 3, ...`).
 */
export interface ILiveKitRevocationCounter extends Document<string> {
  _id: string;
  seq: number;
}

const LiveKitRevocationCounterSchema = new Schema<ILiveKitRevocationCounter>(
  {
    _id: { type: String, required: true },
    seq: { type: Number, required: true, default: 0 },
  },
  { timestamps: false, versionKey: false }
);

export const LiveKitRevocationCounter: Model<ILiveKitRevocationCounter> =
  mongoose.models.LiveKitRevocationCounter ||
  mongoose.model<ILiveKitRevocationCounter>(
    'LiveKitRevocationCounter',
    LiveKitRevocationCounterSchema
  );

export async function allocateNextRevocationSeq(): Promise<number> {
  const counter = await LiveKitRevocationCounter.findOneAndUpdate(
    { _id: 'livekit_revocation_global_seq' },
    { $inc: { seq: 1 } },
    { upsert: true, new: true }
  ).lean();
  return counter ? counter.seq : 1;
}

export interface ILiveKitRevocationEvent extends Document {
  seq: number;
  meetingId: Types.ObjectId;
  userId?: Types.ObjectId | null;
  kind: LiveKitRevocationKind;
  revokedEpoch?: number | null;
  fenceVersion?: number | null;
  reason?: string | null;
  createdAt: Date;
}

const LiveKitRevocationEventSchema = new Schema<ILiveKitRevocationEvent>(
  {
    seq: {
      type: Number,
      required: true,
      unique: true,
      min: 1,
    },
    meetingId: {
      type: Schema.Types.ObjectId,
      ref: 'Meeting',
      required: true,
    },
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    kind: {
      type: String,
      required: true,
      enum: ['PARTICIPANT_REMOVED', 'PARTICIPANT_LEFT', 'MEETING_ENDED'],
    },
    revokedEpoch: {
      type: Number,
      default: null,
      min: 1,
    },
    fenceVersion: {
      type: Number,
      default: null,
      min: 0,
    },
    reason: {
      type: String,
      maxlength: 200,
      default: null,
    },
    createdAt: {
      type: Date,
      required: true,
      default: Date.now,
    },
  },
  {
    timestamps: false,
    versionKey: false,
  }
);

// Fast lookup for cursor sweeps & per-participant fencing queries
LiveKitRevocationEventSchema.index({ meetingId: 1, userId: 1, seq: -1 });
// 24-hour TTL (24x max 1-hour configurable JWT TTL, 144x default 10-min TTL)
// ensures no active unexpired JWT can ever outlive its revocation event.
LiveKitRevocationEventSchema.index({ createdAt: 1 }, { expireAfterSeconds: 86400 });

export const LiveKitRevocationEvent: Model<ILiveKitRevocationEvent> =
  mongoose.models.LiveKitRevocationEvent ||
  mongoose.model<ILiveKitRevocationEvent>(
    'LiveKitRevocationEvent',
    LiveKitRevocationEventSchema
  );
