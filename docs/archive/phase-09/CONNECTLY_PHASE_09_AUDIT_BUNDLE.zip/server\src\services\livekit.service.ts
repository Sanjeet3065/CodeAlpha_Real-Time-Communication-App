import { AccessToken, RoomServiceClient, type VideoGrant } from 'livekit-server-sdk';
import { env } from '../config/env.js';
import type { ParticipantRole } from '../models/MeetingParticipant.model.js';
import { AppError, ServiceUnavailableError } from '../utils/errors.js';
import { logger } from '../utils/logger.js';

export interface LiveKitConfig {
  url: string;
  publicUrl?: string;
  signalGatewayEnabled?: 'auto' | 'true' | 'false';
  apiKey: string;
  apiSecret: string;
  tokenTtlSeconds: number;
}

export interface LiveKitTokenPermissions {
  roomJoin: boolean;
  canPublish: boolean;
  canSubscribe: boolean;
  canPublishData: boolean;
}

export interface LiveKitTokenBundle {
  livekitUrl: string;
  token: string;
  roomName: string;
  participantIdentity: string;
  expiresAt: string;
  ttlSeconds: number;
  role: ParticipantRole;
  permissions: LiveKitTokenPermissions;
}

export interface LiveKitRoomClientAdapter {
  createRoom(options: { name: string; maxParticipants?: number; emptyTimeout?: number }): Promise<unknown>;
  removeParticipant(
    room: string,
    identity: string,
    options?: { revokeTokenTs?: bigint }
  ): Promise<unknown>;
  deleteRoom(room: string): Promise<unknown>;
}

const ROOM_NAME_PREFIX = 'cly_room_';
const PARTICIPANT_IDENTITY_PREFIX = 'usr_';
const DEFAULT_EMPTY_ROOM_TIMEOUT_SECONDS = 300;
const PLACEHOLDER_PREFIXES = ['replace_with_', 'your_livekit_', 'changeme'];

/**
 * Parses a CONNECTLY internal MongoDB meeting ID from an opaque LiveKit room name.
 */
export function parseLiveKitRoomMeetingId(roomName: string): string | null {
  const match = /^cly_room_([a-f0-9]{24})$/.exec(roomName.trim());
  return match ? match[1] : null;
}

/**
 * Parses a CONNECTLY internal MongoDB user ID from an opaque LiveKit participant identity.
 */
export function parseLiveKitParticipantUserId(identity: string): string | null {
  const match = /^usr_([a-f0-9]{24})$/.exec(identity.trim());
  return match ? match[1] : null;
}

export function isLiveKitCloudHost(rawUrl: string): boolean {
  try {
    return new URL(rawUrl).hostname.toLowerCase().endsWith('.livekit.cloud');
  } catch {
    return false;
  }
}

/**
 * Determines whether browser signaling should route through CONNECTLY's
 * authoritative Signaling Admission Gateway before reaching LiveKit SFU.
 *
 * Self-hosted LiveKit OSS (including v1.13.11) does not enforce server-side
 * JWT revocation (`revokeTokenTs`), so routing signaling through CONNECTLY's
 * admission gateway guarantees immediate pre-handshake rejection of removed
 * or revoked participants. Managed LiveKit Cloud (`*.livekit.cloud`) enforces
 * `revokeTokenTs` natively on its control plane.
 */
export function shouldUseLiveKitSignalGateway(
  livekitUrl: string,
  mode: 'auto' | 'true' | 'false' = env.LIVEKIT_SIGNAL_GATEWAY_ENABLED
): boolean {
  if (mode === 'true') return true;
  if (mode === 'false') return false;
  try {
    new URL(livekitUrl);
    return !isLiveKitCloudHost(livekitUrl);
  } catch {
    return false;
  }
}

/**
 * Deterministic, opaque mapping from CONNECTLY internal MongoDB meeting ID
 * to a LiveKit SFU room name. Never embeds titles, emails, or client input.
 */
export function getLiveKitRoomName(meetingId: string): string {
  const clean = meetingId.trim();
  if (!clean || !/^[a-fA-F0-9]{24}$/.test(clean)) {
    throw new AppError('Invalid meeting identifier for LiveKit room mapping.', 400, 'INVALID_IDENTIFIER');
  }
  return `${ROOM_NAME_PREFIX}${clean.toLowerCase()}`;
}

/**
 * Deterministic, privacy-preserving opaque LiveKit participant identity derived
 * strictly from CONNECTLY's internal user ObjectId (never email or phone).
 */
export function getLiveKitParticipantIdentity(userId: string): string {
  const clean = userId.trim();
  if (!clean || !/^[a-fA-F0-9]{24}$/.test(clean)) {
    throw new AppError('Invalid user identifier for LiveKit identity mapping.', 400, 'INVALID_IDENTIFIER');
  }
  return `${PARTICIPANT_IDENTITY_PREFIX}${clean.toLowerCase()}`;
}

/**
 * Converts ws:// -> http:// and wss:// -> https:// for LiveKit server REST/Twirp calls.
 */
export function toLiveKitHttpUrl(rawUrl: string): string {
  const parsed = new URL(rawUrl);
  if (parsed.protocol === 'ws:') {
    parsed.protocol = 'http:';
  } else if (parsed.protocol === 'wss:') {
    parsed.protocol = 'https:';
  }
  return parsed.toString().replace(/\/+$/, '');
}

/**
 * Converts http:// -> ws:// and https:// -> wss:// for browser WebSocket signaling.
 */
export function toLiveKitWsUrl(rawUrl: string): string {
  const parsed = new URL(rawUrl);
  if (parsed.protocol === 'http:') {
    parsed.protocol = 'ws:';
  } else if (parsed.protocol === 'https:') {
    parsed.protocol = 'wss:';
  }
  return parsed.toString().replace(/\/+$/, '');
}

/**
 * Validates LiveKit configuration strictly without ever logging secret material.
 */
export function validateLiveKitConfig(
  config: Partial<LiveKitConfig>,
  nodeEnv: string = env.NODE_ENV
): { valid: true; resolved: LiveKitConfig } | { valid: false; reason: string } {
  const url = (config.url || '').trim();
  const publicUrl = (config.publicUrl || '').trim();
  const rawSignalMode = config.signalGatewayEnabled ?? 'auto';
  if (rawSignalMode !== 'auto' && rawSignalMode !== 'true' && rawSignalMode !== 'false') {
    return {
      valid: false,
      reason: 'LIVEKIT_SIGNAL_GATEWAY_ENABLED must be one of auto, true, or false.',
    };
  }
  const signalGatewayEnabled: 'auto' | 'true' | 'false' = rawSignalMode;
  const apiKey = (config.apiKey || '').trim();
  const apiSecret = (config.apiSecret || '').trim();
  const tokenTtlSeconds =
    typeof config.tokenTtlSeconds === 'number' && Number.isFinite(config.tokenTtlSeconds)
      ? Math.floor(config.tokenTtlSeconds)
      : 600;

  if (!url || !apiKey || !apiSecret) {
    return {
      valid: false,
      reason: 'Missing LIVEKIT_URL, LIVEKIT_API_KEY, or LIVEKIT_API_SECRET.',
    };
  }

  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return { valid: false, reason: 'LIVEKIT_URL is not a valid URL.' };
  }

  const hostLower = parsed.hostname.toLowerCase();
  const isCloud = hostLower.endsWith('.livekit.cloud');
  const isLoopback = hostLower === '127.0.0.1' || hostLower === 'localhost' || hostLower === '::1';

  if (publicUrl) {
    let parsedPub: URL;
    try {
      parsedPub = new URL(publicUrl);
    } catch {
      return { valid: false, reason: 'LIVEKIT_PUBLIC_URL is not a valid URL.' };
    }
    const allowedPubProtocols =
      nodeEnv === 'production' ? ['wss:', 'https:'] : ['ws:', 'wss:', 'http:', 'https:'];
    if (!allowedPubProtocols.includes(parsedPub.protocol)) {
      return {
        valid: false,
        reason:
          nodeEnv === 'production'
            ? 'Production LIVEKIT_PUBLIC_URL must use a secure wss:// or https:// scheme.'
            : 'LIVEKIT_PUBLIC_URL must use ws://, wss://, http://, or https://.',
      };
    }
  }

  if (nodeEnv === 'production' && !isCloud && signalGatewayEnabled === 'false') {
    return {
      valid: false,
      reason:
        'Production self-hosted LiveKit cannot disable LIVEKIT_SIGNAL_GATEWAY_ENABLED (would bypass authoritative JWT revocation).',
    };
  }

  const allowedProtocols =
    nodeEnv === 'production'
      ? publicUrl && isLoopback
        ? ['ws:', 'wss:', 'http:', 'https:']
        : ['wss:', 'https:']
      : ['ws:', 'wss:', 'http:', 'https:'];
  if (!allowedProtocols.includes(parsed.protocol)) {
    return {
      valid: false,
      reason:
        nodeEnv === 'production'
          ? 'Production LIVEKIT_URL must use a secure wss:// or https:// scheme (or private loopback paired with a wss:// LIVEKIT_PUBLIC_URL).'
          : 'LIVEKIT_URL must use ws://, wss://, http://, or https://.',
    };
  }

  const keyLower = apiKey.toLowerCase();
  const secretLower = apiSecret.toLowerCase();
  if (
    PLACEHOLDER_PREFIXES.some(
      (prefix) => keyLower.startsWith(prefix) || secretLower.startsWith(prefix)
    )
  ) {
    return {
      valid: false,
      reason: 'LiveKit credentials contain unconfigured placeholder values.',
    };
  }

  if (nodeEnv === 'production' && (keyLower === 'devkey' || secretLower === 'secret')) {
    return {
      valid: false,
      reason: 'Production deployment cannot use default LiveKit dev credentials.',
    };
  }

  if (tokenTtlSeconds < 60 || tokenTtlSeconds > 3600) {
    return {
      valid: false,
      reason: 'LIVEKIT_TOKEN_TTL_SECONDS must be between 60 and 3600 seconds.',
    };
  }

  return {
    valid: true,
    resolved: {
      url: toLiveKitWsUrl(url),
      publicUrl: publicUrl ? toLiveKitWsUrl(publicUrl) : undefined,
      signalGatewayEnabled,
      apiKey,
      apiSecret,
      tokenTtlSeconds,
    },
  };
}

function isNotFoundLiveKitError(err: unknown): boolean {
  if (!err || typeof err !== 'object') return false;
  const e = err as { status?: number; code?: string | number; message?: string };
  if (e.status === 404 || e.code === 'not_found' || e.code === 404) return true;
  const msg = String(e.message || '').toLowerCase();
  return msg.includes('not found') || msg.includes('does not exist') || msg.includes('room not found');
}

function isAlreadyExistsLiveKitError(err: unknown): boolean {
  if (!err || typeof err !== 'object') return false;
  const e = err as { status?: number; code?: string | number; message?: string };
  if (e.status === 409 || e.code === 'already_exists') return true;
  const msg = String(e.message || '').toLowerCase();
  return msg.includes('already exists');
}

export class LiveKitService {
  private readonly customConfig?: Partial<LiveKitConfig>;
  private readonly nodeEnvOverride?: string;
  private readonly roomClientFactory?: (httpUrl: string, apiKey: string, apiSecret: string) => LiveKitRoomClientAdapter;
  private cachedClientKey: string | null = null;
  private cachedClient: LiveKitRoomClientAdapter | null = null;

  constructor(options?: {
    config?: Partial<LiveKitConfig>;
    nodeEnv?: string;
    roomClientFactory?: (httpUrl: string, apiKey: string, apiSecret: string) => LiveKitRoomClientAdapter;
  }) {
    this.customConfig = options?.config;
    this.nodeEnvOverride = options?.nodeEnv;
    this.roomClientFactory = options?.roomClientFactory;
  }

  private readCurrentConfig(): Partial<LiveKitConfig> {
    if (this.customConfig) {
      return this.customConfig;
    }
    const rawMode = (
      process.env.LIVEKIT_SIGNAL_GATEWAY_ENABLED ?? env.LIVEKIT_SIGNAL_GATEWAY_ENABLED
    ) as 'auto' | 'true' | 'false';
    return {
      url: process.env.LIVEKIT_URL ?? env.LIVEKIT_URL,
      publicUrl: process.env.LIVEKIT_PUBLIC_URL ?? env.LIVEKIT_PUBLIC_URL,
      signalGatewayEnabled: rawMode,
      apiKey: process.env.LIVEKIT_API_KEY ?? env.LIVEKIT_API_KEY,
      apiSecret: process.env.LIVEKIT_API_SECRET ?? env.LIVEKIT_API_SECRET,
      tokenTtlSeconds: env.LIVEKIT_TOKEN_TTL_SECONDS,
    };
  }

  public isConfigured(): boolean {
    const check = validateLiveKitConfig(this.readCurrentConfig(), this.nodeEnvOverride ?? env.NODE_ENV);
    return check.valid;
  }

  public assertConfigured(): LiveKitConfig {
    const check = validateLiveKitConfig(this.readCurrentConfig(), this.nodeEnvOverride ?? env.NODE_ENV);
    if (!check.valid) {
      logger.warn('[LiveKit] Configuration check failed', {
        errorCategory: 'LIVEKIT_NOT_CONFIGURED',
        reason: check.reason,
      });
      throw new ServiceUnavailableError(
        'Real-time media infrastructure (LiveKit) is not configured on this server.',
        'LIVEKIT_NOT_CONFIGURED'
      );
    }
    return check.resolved;
  }

  private getRoomClient(cfg: LiveKitConfig): LiveKitRoomClientAdapter {
    const httpUrl = toLiveKitHttpUrl(cfg.url);
    const cacheKey = `${httpUrl}|${cfg.apiKey}`;
    if (this.cachedClient && this.cachedClientKey === cacheKey) {
      return this.cachedClient;
    }
    const client: LiveKitRoomClientAdapter = this.roomClientFactory
      ? this.roomClientFactory(httpUrl, cfg.apiKey, cfg.apiSecret)
      : new RoomServiceClient(httpUrl, cfg.apiKey, cfg.apiSecret);
    this.cachedClient = client;
    this.cachedClientKey = cacheKey;
    return client;
  }

  /**
   * Lazily ensures the LiveKit SFU room exists for an authorized CONNECTLY meeting.
   * Safe under concurrent calls (idempotent if the room already exists).
   */
  public async ensureRoomExists(
    meetingId: string,
    maxParticipants: number,
    requestId?: string
  ): Promise<string> {
    const cfg = this.assertConfigured();
    const roomName = getLiveKitRoomName(meetingId);
    const client = this.getRoomClient(cfg);

    try {
      await client.createRoom({
        name: roomName,
        maxParticipants,
        emptyTimeout: DEFAULT_EMPTY_ROOM_TIMEOUT_SECONDS,
      });
      return roomName;
    } catch (err) {
      if (isAlreadyExistsLiveKitError(err)) {
        return roomName;
      }
      logger.error('[LiveKit] Failed to reach LiveKit server while provisioning room', {
        requestId,
        meetingId,
        roomName,
        errorCategory: 'LIVEKIT_UNAVAILABLE',
        message: err instanceof Error ? err.message : 'Unknown LiveKit transport error',
      });
      throw new ServiceUnavailableError(
        'LiveKit media server is currently unreachable. Please try reconnecting shortly.',
        'LIVEKIT_UNAVAILABLE'
      );
    }
  }

  /**
   * Issues a short-lived, least-privilege LiveKit JWT for a verified ADMITTED participant.
   *
   * Strict Phase 09 Permission Boundary:
   * - roomJoin: true (room connection & signaling only)
   * - canPublish: false, canSubscribe: false, canPublishData: false (Phase 10 owns media tracks)
   * - roomAdmin / roomCreate / roomList / roomRecord: ALWAYS false for every role
   */
  public async generateParticipantToken(params: {
    meetingId: string;
    userId: string;
    displayName: string;
    role: ParticipantRole;
    maxParticipants: number;
    tokenEpoch?: number;
    gatewayUrl?: string;
    requestId?: string;
    provisionRoom?: boolean;
  }): Promise<LiveKitTokenBundle> {
    const cfg = this.assertConfigured();
    const roomName = getLiveKitRoomName(params.meetingId);
    const participantIdentity = getLiveKitParticipantIdentity(params.userId);
    const tokenEpoch =
      typeof params.tokenEpoch === 'number' && Number.isInteger(params.tokenEpoch) && params.tokenEpoch >= 1
        ? params.tokenEpoch
        : 1;

    if (params.provisionRoom !== false) {
      await this.ensureRoomExists(params.meetingId, params.maxParticipants, params.requestId);
    }

    const permissions: LiveKitTokenPermissions = {
      roomJoin: true,
      canPublish: false,
      canSubscribe: false,
      canPublishData: false,
    };

    const grant: VideoGrant = {
      roomJoin: permissions.roomJoin,
      room: roomName,
      canPublish: permissions.canPublish,
      canSubscribe: permissions.canSubscribe,
      canPublishData: permissions.canPublishData,
      roomAdmin: false,
      roomCreate: false,
      roomList: false,
      roomRecord: false,
    };

    const activeNodeEnv = this.nodeEnvOverride ?? env.NODE_ENV;
    const publicOverride = (cfg.publicUrl || '').trim();
    const signalMode: 'auto' | 'true' | 'false' = cfg.signalGatewayEnabled ?? 'auto';
    const requiresGateway = shouldUseLiveKitSignalGateway(cfg.url, signalMode);
    let clientLivekitUrl = cfg.url;

    if (publicOverride) {
      clientLivekitUrl = toLiveKitWsUrl(publicOverride);
    } else if (requiresGateway && params.gatewayUrl) {
      const candidateGatewayUrl = toLiveKitWsUrl(params.gatewayUrl);
      if (activeNodeEnv === 'production' && !candidateGatewayUrl.startsWith('wss://')) {
        throw new ServiceUnavailableError(
          'Production LiveKit Signaling Admission Gateway requires a secure wss:// URL.',
          'LIVEKIT_NOT_CONFIGURED'
        );
      }
      clientLivekitUrl = candidateGatewayUrl;
    } else if (requiresGateway && activeNodeEnv === 'production') {
      // Fail closed in production: NEVER fall back silently to raw self-hosted LiveKit signaling
      throw new ServiceUnavailableError(
        'Production self-hosted LiveKit requires LIVEKIT_PUBLIC_URL or an HTTPS/WSS Signaling Admission Gateway.',
        'LIVEKIT_NOT_CONFIGURED'
      );
    }

    try {
      const accessToken = new AccessToken(cfg.apiKey, cfg.apiSecret, {
        identity: participantIdentity,
        name: params.displayName,
        ttl: cfg.tokenTtlSeconds,
        metadata: JSON.stringify({
          role: params.role,
          meetingId: params.meetingId,
          epoch: tokenEpoch,
        }),
      });
      accessToken.addGrant(grant);

      const jwt = await accessToken.toJwt();
      const expiresAt = new Date(Date.now() + cfg.tokenTtlSeconds * 1000).toISOString();

      logger.info('[LiveKit] Issued short-lived room access token', {
        requestId: params.requestId,
        meetingId: params.meetingId,
        roomName,
        participantIdentity,
        role: params.role,
        tokenEpoch,
        ttlSeconds: cfg.tokenTtlSeconds,
        viaSignalGateway: clientLivekitUrl !== cfg.url,
      });

      return {
        livekitUrl: clientLivekitUrl,
        token: jwt,
        roomName,
        participantIdentity,
        expiresAt,
        ttlSeconds: cfg.tokenTtlSeconds,
        role: params.role,
        permissions,
      };
    } catch (err) {
      logger.error('[LiveKit] Token signing failed', {
        requestId: params.requestId,
        meetingId: params.meetingId,
        participantIdentity,
        errorCategory: 'LIVEKIT_TOKEN_GENERATION_FAILED',
        message: err instanceof Error ? err.message : 'Token signing error',
      });
      throw new AppError(
        'Unable to generate secure media session token.',
        500,
        'LIVEKIT_TOKEN_GENERATION_FAILED'
      );
    }
  }

  /**
   * Disconnects a removed or departed participant from the LiveKit SFU room.
   * Best-effort with sanitized error logging so CONNECTLY DB state remains authoritative.
   */
  public async removeParticipant(
    meetingId: string,
    userId: string,
    requestId?: string
  ): Promise<boolean> {
    if (!this.isConfigured()) {
      return false;
    }

    const cfg = this.assertConfigured();
    const roomName = getLiveKitRoomName(meetingId);
    const participantIdentity = getLiveKitParticipantIdentity(userId);
    const client = this.getRoomClient(cfg);

    // Pass revokeTokenTs (now + 1s) so LiveKit Cloud natively invalidates any
    // token whose nbf <= now (including same-second tokens). Self-hosted OSS
    // LiveKit Server v1.13.11 ignores revokeTokenTs and only disconnects active
    // sessions; pre-admission revocation on self-hosted is enforced by
    // livekitSignalGateway against authoritative MongoDB state + tokenEpoch.
    const revokeTokenTs = BigInt(Math.floor(Date.now() / 1000) + 1);

    try {
      await client.removeParticipant(roomName, participantIdentity, { revokeTokenTs });
      logger.info('[LiveKit] Evicted participant from SFU room', {
        requestId,
        meetingId,
        roomName,
        participantIdentity,
        revokeTokenTs: revokeTokenTs.toString(),
      });
      return true;
    } catch (err) {
      if (isNotFoundLiveKitError(err)) {
        return true;
      }
      logger.warn('[LiveKit] Failed to evict participant from SFU room (non-fatal)', {
        requestId,
        meetingId,
        roomName,
        participantIdentity,
        errorCategory: 'LIVEKIT_UNAVAILABLE',
        message: err instanceof Error ? err.message : 'Unknown eviction error',
      });
      return false;
    }
  }

  /**
   * Closes/deletes the LiveKit SFU room when a CONNECTLY meeting ends.
   * Performs 1 bounded retry on transient failure; falls back safely to LiveKit's
   * emptyTimeout reconciliation while logging safe diagnostic metadata.
   */
  public async deleteRoom(meetingId: string, requestId?: string): Promise<boolean> {
    if (!this.isConfigured()) {
      return false;
    }

    const cfg = this.assertConfigured();
    const roomName = getLiveKitRoomName(meetingId);
    const client = this.getRoomClient(cfg);

    for (let attempt = 1; attempt <= 2; attempt += 1) {
      try {
        await client.deleteRoom(roomName);
        logger.info('[LiveKit] Deleted SFU room upon meeting termination', {
          requestId,
          meetingId,
          roomName,
          attempt,
        });
        return true;
      } catch (err) {
        if (isNotFoundLiveKitError(err)) {
          return true;
        }
        logger.warn('[LiveKit] Room cleanup attempt failed', {
          requestId,
          meetingId,
          roomName,
          attempt,
          errorCategory: 'LIVEKIT_UNAVAILABLE',
          message: err instanceof Error ? err.message : 'Unknown room deletion error',
        });
      }
    }

    return false;
  }
}

export const livekitService = new LiveKitService();
