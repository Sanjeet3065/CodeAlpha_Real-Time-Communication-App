# CONNECTLY — Phase 09 Security Audit Report

**Phase:** 09 – WebRTC + LiveKit Integration  
**Audit Date:** 2026-11-18 (Updated following independent Removed-Participant Token Reuse & `revokeTokenTs` Security Audit)  
**Deployed & Verified Versions:** `livekit-server-sdk@2.20.0` (backend), `livekit-client@2.24.1` (frontend), self-hosted `livekit-server version 1.13.11` (OSS binary compiled from `github.com/livekit/livekit@v1.13.11`).

---

## 1. Executive Security Finding: Self-Hosted LiveKit `v1.13.11` Token Revocation Audit

### 1.1 Source-Code & Experimental Investigation (`livekit-server-sdk@2.20.0` vs. `livekit-server v1.13.11`)

An independent security audit inspected both the installed SDK (`livekit-server-sdk@2.20.0`) and the compiled LiveKit Server `v1.13.11` Go source code, and executed live multi-browser token-reuse experiments:

1. **SDK Protocol Support (`livekit-server-sdk@2.20.0`):** `RoomServiceClient.removeParticipant(room, identity, { revokeTokenTs?: bigint })` exposes `revokeTokenTs` (`int64 revoke_token_ts = 3` in `livekit.RoomParticipantIdentity`).
2. **Self-Hosted Server Reality (`github.com/livekit/livekit@v1.13.11`):**
   - Searching the entire `livekit@v1.13.11` Go source tree for `RevokeTokenTs` / `revoke_token_ts` returned **0 occurrences**.
   - `pkg/service/roomservice.go:226-247` checks `HasParticipant` (returning `404 participant does not exist` when offline, even when `revokeTokenTs` is supplied) and forwards to `roommanager.go:861-870`, which only disconnects the active peer (`SERVICE_REQUEST_REMOVE_PARTICIPANT`) without storing any revocation cutoff.
   - `pkg/service/auth.go:86-117` (`APIKeyAuthMiddleware`) verifies only JWT HMAC signature, `nbf`, and `exp` via `v.Verify(secret)` — there is no revocation table in OSS `v1.13.11`.
3. **Experimental Pre-Mitigation Proof (Raw `ws://127.0.0.1:7880`):**
   - Host removed Guest via CONNECTLY's Phase 08 `DELETE /api/v1/meetings/:code/participants/:id` (`200 OK`).
   - Guest was disconnected (`Disconnected`, reason `4` = `PARTICIPANT_REMOVED`) and denied new CONNECTLY tokens (`403 PARTICIPANT_REMOVED`).
   - **HOWEVER**, reconnecting directly to raw `ws://127.0.0.1:7880` using the **exact original unexpired JWT** succeeded (`reconnected: true`, `remoteCount: 1`) in:
     - Same browser context (without requesting a new token).
     - Fresh isolated Chrome browser context.
     - After calling `removeParticipant(room, identity, { revokeTokenTs: now + 5s })` while online (LiveKit logged `"revokeTokenTs": 1794970853`, returned `200`, and still started a new RTC session 2 seconds later with the old JWT).
     - After a full browser disconnect + `removeParticipant(..., { revokeTokenTs })` while offline (LiveKit returned `404 participant does not exist`, and reconnecting with the original JWT succeeded).

### 1.2 Implemented Mitigation: Authoritative Signaling Admission Gateway + Signed `tokenEpoch` + Cloud `revokeTokenTs`

To block old-token reuse **immediately (0 ms post-join race window)** on self-hosted LiveKit **without disrupting Host or any other admitted participant**:

1. **Authoritative LiveKit Signaling Admission Gateway ([livekitSignalGateway.ts](file:///c:/Users/SANJEET%20CHAUHAN/Desktop/code%20Alpha/antigravity%20communication%20application/server/src/realtime/livekitSignalGateway.ts)):**
   - Mounted on CONNECTLY's HTTP/WebSocket server at `/livekit-signal` (`HEAD /livekit-signal`, `GET /livekit-signal/rtc[/v1]/validate`, and WebSocket `UPGRADE /livekit-signal/rtc[/v1]`), leaving `/socket.io` untouched.
   - Automatically enabled (`LIVEKIT_SIGNAL_GATEWAY_ENABLED=auto`) for all self-hosted LiveKit deployments (non-`*.livekit.cloud` hosts); browsers receive `livekitUrl: ws(s)://<api-host>/livekit-signal`.
   - **Pre-Admission Gate (executes BEFORE any packet reaches LiveKit SFU):** Cryptographically verifies the LiveKit JWT (`TokenVerifier`), validates opaque room/identity mapping, queries authoritative MongoDB (`Meeting` + `MeetingParticipant`), and rejects with HTTP `403` / `410` if:
     - Meeting is `ENDED` or `EXPIRED` (`410 LIVEKIT_MEETING_ENDED`).
     - Participant is `REMOVED` (`403 PARTICIPANT_REMOVED`) or not `ADMITTED` (`403 LIVEKIT_ACCESS_DENIED`).
     - Signed JWT `metadata.epoch` does not match MongoDB `MeetingParticipant.tokenEpoch` (`403 LIVEKIT_TOKEN_REVOKED`).
     - JWT `nbf` predates `MeetingParticipant.tokenRevokedBefore` (`403 LIVEKIT_TOKEN_REVOKED`).
   - **Per-Participant Socket Termination:** On removal or leave, only the removed/departed participant's active proxied signaling sockets are closed (`disconnectParticipantSockets`), leaving Host and all other admitted participants connected with **zero disruption**.
   - **Zero JWT Log Leakage:** [requestLogger.ts](file:///c:/Users/SANJEET%20CHAUHAN/Desktop/code%20Alpha/antigravity%20communication%20application/server/src/middlewares/requestLogger.ts) redacts `access_token`, `token`, and `join_request` query parameters before logging.
2. **Monotonic Signed `tokenEpoch` & Post-Generation TOCTOU Guard:**
   - `MeetingParticipant` stores `tokenEpoch` (default `1`, atomically `$inc: 1` on `removeParticipant` and `leaveMeeting`) and `tokenRevokedBefore`.
   - Every LiveKit JWT embeds `epoch` inside HMAC-signed `metadata`, and `issueLiveKitToken` re-verifies `admissionStatus === 'ADMITTED'` AND `tokenEpoch === expectedTokenEpoch` after room provisioning before returning any token.
   - Permanently invalidates pre-departure unexpired JWTs even if a user leaves and legitimately rejoins within the same second.
3. **LiveKit Cloud `revokeTokenTs` Compatibility:**
   - `LiveKitService.removeParticipant` forwards `{ revokeTokenTs: BigInt(Math.floor(Date.now() / 1000) + 1) }` so LiveKit Cloud deployments also benefit from native Cloud control-plane token revocation.

### 1.3 Explicit Security State Distinction Matrix

| Security Dimension | Self-Hosted `v1.13.11` via CONNECTLY `/livekit-signal` Gateway (Default) | Direct to Raw Self-Hosted `v1.13.11` (`:7880` if exposed) | Managed LiveKit Cloud (`*.livekit.cloud`) |
| --- | --- | --- | --- |
| **Participant disconnected** | **YES — Immediate** (`removeParticipant` + per-participant gateway socket teardown; zero disruption to other peers) | **YES — Immediate** (while online; `404` when offline) | **YES — Immediate** |
| **Existing JWT revoked** | **YES — Immediate at Gateway** (`admissionStatus=REMOVED` + `tokenEpoch` mismatch + `tokenRevokedBefore` checked pre-handshake) | **NO — Not supported by OSS `v1.13.11`** (`revokeTokenTs` ignored) | **YES — Cloud control plane** (via `revokeTokenTs`, 10-min Cloud window) |
| **Existing JWT still valid** | **NO at Gateway** (cryptographically signed, but permanently rejected with HTTP `403` pre-upgrade) | **YES** (remains valid at raw `:7880` until `exp`, default `600s`) | **NO** (rejected by Cloud `nbf < revoke_token_ts` cutoff) |
| **New token request denied** | **YES — Immediate** (`403 PARTICIPANT_REMOVED`; stale in-flight requests also rejected) | **YES — Immediate** (`403 PARTICIPANT_REMOVED` from CONNECTLY API) | **YES — Immediate** (`403 PARTICIPANT_REMOVED`) |
| **Old-token reconnection** | **DENIED (HTTP `403`)** across same browser, auto-reconnect, fresh browser context, and offline-then-removed | **STILL POSSIBLE** if client network can directly reach raw `:7880` | **DENIED** by LiveKit Cloud control plane |

> **Mandatory Self-Hosted Production Network Boundary:** Because self-hosted LiveKit Server `v1.13.11` itself lacks native JWT revocation, production self-hosted deployments **MUST** bind LiveKit's raw HTTP/WS signaling port (`7880`) to a private loopback/VPC interface reachable **only** by the CONNECTLY Signaling Admission Gateway (never directly from untrusted client browsers). Only ICE/WebRTC media ports (`7881/TCP`, UDP media range) are exposed, and WebRTC media cannot be established without completing the gateway-authorized `/rtc` signaling handshake.

### 1.4 Final Gateway Race-Condition, Bypass & Fail-Closed Audit (7-Boundary Verification)

A focused follow-up audit identified and resolved four subtle gateway concurrency and deployment edge cases:

1. **7-Boundary Handshake-vs-Removal TOCTOU Race (Fixed & Barrier-Tested):**
   - *Vulnerability found:* Previously, if `removeParticipant` ran after initial gateway authorization but before upstream WebSocket upgrade completed, `disconnectParticipantSockets` saw zero registered sockets and the late-completing upstream `101` could leave a removed participant connected.
   - *Fix implemented ([livekitSignalGateway.ts](file:///c:/Users/SANJEET%20CHAUHAN/Desktop/code%20Alpha/antigravity%20communication%20application/server/src/realtime/livekitSignalGateway.ts)):*
     - Tracks every in-flight handshake (`pendingByParticipant` / `pendingByMeeting`) immediately upon initial authorization so `disconnectParticipantSockets` / `disconnectMeetingSockets` / `close()` aborts pending upstream requests instantly.
     - Executes an authoritative pre-upstream MongoDB re-check AND a **mandatory post-handshake MongoDB revalidation** (`revalidateParticipantAccess`) AFTER registering `(clientSocket, proxySocket)` and BEFORE sending `HTTP/1.1 101 Switching Protocols` to the client.
     - If removal committed on the same instance OR on another API instance (cross-instance MongoDB), the upgraded upstream socket is destroyed, HTTP `403`/`410` is returned (never `101`), and best-effort `livekit.removeParticipant` is invoked.
   - *Verified deterministically ([livekitGatewaySecurity.test.ts](file:///c:/Users/SANJEET%20CHAUHAN/Desktop/code%20Alpha/antigravity%20communication%20application/server/src/tests/livekitGatewaySecurity.test.ts) Tests 1–2):* All 7 exact boundaries (`beforeAuthorize`, `afterAuthorize`, `beforeUpstreamConnect`, `duringUpstreamHandshake`, `afterUpstreamHandshake`, `duringSocketRegister`, `afterSocketRegister`), cross-instance removal, and a simultaneous 5x connection burst with the same old JWT leave **0** active removed sockets while Host remains connected uninterrupted.
2. **Half-Open Socket Cleanup & Graceful Shutdown (Fixed & Verified):**
   - Added `'end'` listeners alongside `'close'`/`'error'` so TCP FIN from either peer immediately destroys and untracks both sockets (`getActiveSocketCount() === 0`).
   - Added `livekitSignalGateway.close()` and wired it into `server/src/server.ts`'s graceful `SIGTERM`/`SIGINT` shutdown handler (`getActiveSocketCount() === 0`, subsequent upgrades receive `503`).
3. **Alternate Route Locking & Fail-Closed MongoDB (Fixed & Verified):**
   - All alternate WebSocket upgrade routes (`/rtc`, `/rtc/v1`, `/livekit-signal/rtc/v2`, `/livekit-signal/*`) and unknown HTTP routes return `404` without reaching LiveKit (leaving `/socket.io` untouched).
   - MongoDB query errors inside `authorizeLiveKitSignalHandshake` / `revalidateParticipantAccess` strictly fail CLOSED (`503 LIVEKIT_AUTH_UNAVAILABLE`).
   - Missing/malformed `epoch` metadata, cross-meeting metadata mismatches, and outsider tokens are rejected (`403`).
4. **Anti-Bypass Production Transport Enforcement (Fixed & Verified):**
   - `env.ts` and `validateLiveKitConfig` reject `LIVEKIT_SIGNAL_GATEWAY_ENABLED=false` for self-hosted production deployments (preventing silent gateway bypass) and enforce `wss://` for `LIVEKIT_PUBLIC_URL` / production gateway URLs.
   - Removed client-side `VITE_LIVEKIT_URL` direct fallback in `useLiveKitConnection.ts` and `livekitClient.ts` so browsers strictly use the authoritative backend `livekitUrl`.
   - Local development verification (real loopback `127.0.0.1:7880` behind `localhost:5000/livekit-signal`) is explicitly distinguished from production infrastructure verification (TLS reverse proxy + VPC port `7880` firewall isolation, documented in `PHASE_09_LIVEKIT_SETUP.md` and verified during Phase 18 Deployment).

### 1.5 Cross-Instance Distributed Revocation, Atomic Linearization & Post-Sync 101 Fencing Audit

A deep distributed-systems audit examined both the post-`syncNow()` / post-final-read `HTTP 101` race and cross-instance event delivery semantics across independent Gateway & API nodes:

1. **Atomic MongoDB Linearization Point (`claimSignalingAdmissionFence` vs. `removeParticipant`):**
   - *Key distributed-systems fact:* Neither a MongoDB read followed by an OS socket `write(101)` nor `coordinator.syncNow()` alone provides cross-instance linearizability.
   - *Implemented linearization mechanism ([livekitSignalGateway.ts](file:///c:/Users/SANJEET%20CHAUHAN/Desktop/code%20Alpha/antigravity%20communication%20application/server/src/realtime/livekitSignalGateway.ts), [MeetingParticipant.model.ts](file:///c:/Users/SANJEET%20CHAUHAN/Desktop/code%20Alpha/antigravity%20communication%20application/server/src/models/MeetingParticipant.model.ts), [meeting.service.ts](file:///c:/Users/SANJEET%20CHAUHAN/Desktop/code%20Alpha/antigravity%20communication%20application/server/src/services/meeting.service.ts)):*
     - Both signaling admission (`claimSignalingAdmissionFence`) and participant removal (`removeParticipant`) execute an **atomic single-document conditional `findOneAndUpdate`** on the exact same `MeetingParticipant` MongoDB document, incrementing monotonic `signalFenceVersion`.
     - **Case A — Removal linearizes BEFORE Admission (including after `syncNow()` and after final MongoDB read, even while revocation delivery is paused):** `claimSignalingAdmissionFence` atomically returns `null` (loses the document race). The gateway destroys the upstream socket, returns `403`, and **NEVER emits `HTTP 101`**.
     - **Case B — Admission linearizes BEFORE Removal:** Admission won the MongoDB document lock with `signalFenceVersion = k`; removal subsequently commits `admissionStatus = 'REMOVED'`, `tokenEpoch = E + 1`, `signalFenceVersion = k + 1`, and publishes a durable `LiveKitRevocationEvent`. Because the socket pair was already registered before the linearization point, `LiveKitRevocationCoordinator` deterministically terminates the established socket upon event delivery. **Unavoidable propagation interval (disclosed honestly):** If a gateway process stalls *after* winning `claimSignalingAdmissionFence` and *before* kernel `socket.write(101)` while asynchronous revocation delivery is delayed, `HTTP 101` reflects the pre-removal linearized admission and is then unconditionally terminated once the durable revocation event propagates to that gateway.
     - **Fail-Closed Fence:** If `claimSignalingAdmissionFence` encounters any MongoDB error, it returns `503 LIVEKIT_FENCE_UNAVAILABLE` and never emits `HTTP 101`.
2. **Durable Global-Sequence Event Delivery (`LiveKitRevocationCounter` + `LiveKitRevocationEvent` + `LiveKitRevocationCoordinator`):**
   - **Clock-Skew-Independent Monotonic `seq`:** Every revocation event atomically allocates a global integer `seq` (`1, 2, 3, ...`) from `LiveKitRevocationCounter`, preventing skipped events caused by cross-host `ObjectId` clock skew.
   - **Zero Skipped Events & Out-of-Order Safety:** `lastContiguousSeq` advances strictly across contiguous sequences (holding a bounded grace window for in-flight out-of-order commits while dispatching higher-`seq` events immediately with exact `dispatchedSeqs` deduplication). Epoch fencing (`entry.tokenEpoch < event.revokedEpoch`) prevents delayed old-epoch events from disrupting newer re-admitted sessions.
   - **Change Stream Resume & Standalone Polling (Separately Defined):**
     - *MongoDB Replica Set (Production):* Real-time push via Change Stream (`watch`), capturing `resumeAfter` tokens for reconnect recovery and running periodic durable `seq` cursor catch-up (`pollIntervalMs`, default `250ms`). Delivery latency is determined by MongoDB oplog commit + network RTT + event-loop scheduling (no unmeasured hard millisecond SLA is claimed).
     - *Standalone MongoDB (Local Dev / CI):* Automatically uses indexed durable `seq` cursor sweeps (`pollIntervalMs`, default `250ms`) with no Change Stream dependency.
   - **TTL Retention & Stalled-Delivery Watchdog (Fail-Closed):**
     - `LiveKitRevocationEvent` TTL is **24 hours (`86400s` — 24x max 1-hour JWT TTL, 144x default 10-min TTL)** so no unexpired JWT can outlive its revocation event; cursor discontinuity detection fails closed if an extended outage causes a retention gap.
     - `coordinator.isHealthy()` enforces both `maxConsecutiveFailures` (`2`) AND a **stalled-delivery watchdog** (`Date.now() - lastSuccessfulSyncAt > maxStaleDeliveryMs`), failing closed (`503` + active socket termination) even if delivery stalls without throwing DB exceptions.
   - *Verified deterministically ([livekitCrossInstanceRevocation.test.ts](file:///c:/Users/SANJEET%20CHAUHAN/Desktop/code%20Alpha/antigravity%20communication%20application/server/src/tests/livekitCrossInstanceRevocation.test.ts) 7/7 PASS & [livekitPostSyncFencing.test.ts](file:///c:/Users/SANJEET%20CHAUHAN/Desktop/code%20Alpha/antigravity%20communication%20application/server/src/tests/livekitPostSyncFencing.test.ts) 6/6 PASS).*

---

## 2. Secret Management & Client Bundle Isolation

- **Server-Only Credentials:** `LIVEKIT_API_KEY` and `LIVEKIT_API_SECRET` exist strictly in server environment variables (`server/src/config/env.ts`) and are NEVER returned by any API endpoint, Socket.IO event, or `VITE_` frontend variable.
- **Production Boot Fail-Safe:** In `NODE_ENV=production`, `env.ts` refuses to start if `LIVEKIT_URL`, `LIVEKIT_API_KEY`, or `LIVEKIT_API_SECRET` is missing, uses an insecure scheme (`ws://` / `http://`), or uses placeholder/dev credentials (`devkey`, `secret`, `replace_with_*`).
- **No Mock Fallback:** When LiveKit configuration is absent, `POST /api/v1/meetings/:code/livekit-token` returns `503 LIVEKIT_NOT_CONFIGURED`.
- **Client Bundle, Web Storage & Log Verification:**
  - Compiled `client/dist/assets/*.js`: **0** secret occurrences.
  - Chrome CDP Web Storage (`localStorage` / `sessionStorage`): **0** LiveKit JWTs stored.
  - Express HTTP logs (`requestLogger.ts`): `access_token=[REDACTED]` verified live against real browser traffic.

---

## 3. Least-Privilege Token Permission Model (Phase 09 Boundary)

Verified cryptographically with LiveKit's `TokenVerifier` (`livekitService.test.ts` Tests 3 & 7, `livekitTokenAuth.test.ts` Test 3):

| Claim / Grant | Value Issued (All Roles) | Rationale |
| --- | --- | --- |
| `sub` (Identity) | `usr_<mongoUserId>` | Opaque internal ID; zero email/phone PII |
| `video.room` | `cly_room_<mongoMeetingId>` | Server-derived from MongoDB; client cannot choose room |
| `metadata` | `{"role":"...","meetingId":"...","epoch":N}` | HMAC-signed monotonic token epoch for immediate gateway revocation |
| `video.roomJoin` | `true` | Allows WebRTC signaling & room entry |
| `video.canPublish` | **`false`** | Media publishing strictly deferred to Phase 10 |
| `video.canSubscribe` | **`false`** | Media subscription strictly deferred to Phase 10 |
| `video.canPublishData` | **`false`** | Data channels deferred to later phases |
| `video.roomAdmin` / `roomCreate` / `roomList` / `roomRecord` | **`false`** | Never granted to any client role |
| TTL (`exp - nbf`) | **`600s` (10 min)** | Short-lived credential window |

---

## 4. Exact Reconciliation: 14 Server-Side Token Issuance Checks vs. 20 Tested Security Scenarios

Previous documentation cited **14 authorization checks** on the token endpoint and **18 security scenarios** in the test matrix without cross-referencing them. The exact 1-to-1 reconciliation is documented below.

### 4.1 The 14 Server-Side Token Issuance Gate Checks (`POST /api/v1/meetings/:meetingCode/livekit-token`)

| Check # | Layer & File | Exact Check Enforced | Failure Status / Code |
| ---: | --- | --- | --- |
| 1 | Middleware (`auth.middleware.ts`) | `requireAuth` — valid authenticated Bearer/session JWT | `401 UNAUTHORIZED` |
| 2 | Middleware (`csrf.middleware.ts`) | `validateRequestOrigin` — rejects untrusted `Origin`/`Referer` | `403 CSRF_INVALID_ORIGIN` / `CSRF_INVALID_REFERER` |
| 3 | Middleware (`rateLimiter.ts`) | `livekitTokenLimiter` — `60 req / 5 min / IP` | `429 RATE_LIMIT_EXCEEDED` |
| 4 | Middleware (`meeting.schema.ts`) | `livekitTokenRequestSchema = z.strictObject({})` — blocks forged `role`, `roomName`, `identity`, `userId`, `canPublish` | `400 VALIDATION_ERROR` |
| 5 | Service (`meeting.service.ts:1747`) | Valid MongoDB `ObjectId` for authenticated `userId` | `400 INVALID_IDENTIFIER` |
| 6 | Service (`meeting.service.ts:1751`) | Valid canonical meeting code (`cly-xxx-xxx`) + meeting exists in MongoDB | `400 INVALID_MEETING_CODE` / `404 MEETING_NOT_FOUND` |
| 7 | Service (`meeting.service.ts:1752`) | Meeting is neither `ENDED` nor `EXPIRED` (enforces expiration atomically) | `410 LIVEKIT_MEETING_ENDED` / `410 MEETING_EXPIRED` |
| 8 | Service (`meeting.service.ts:1772`) | Participant record exists (if absent and locked -> `MEETING_LOCKED`; else `LIVEKIT_ACCESS_DENIED`) | `403 MEETING_LOCKED` / `403 LIVEKIT_ACCESS_DENIED` |
| 9 | Service (`meeting.service.ts:1785`) | Participant `admissionStatus !== 'REMOVED'` | `403 PARTICIPANT_REMOVED` |
| 10 | Service (`meeting.service.ts:1792`) | Participant `admissionStatus === 'ADMITTED'` (rejects `WAITING`, `REJECTED`, `LEFT`, `CANCELLED`) | `403 LIVEKIT_ACCESS_DENIED` |
| 11 | Service (`meeting.service.ts:1801`) | Meeting capacity bound (`activeParticipantCount <= maxParticipants`) | `403 MEETING_FULL` |
| 12 | Service (`livekit.service.ts:276`) | LiveKit config present & production-valid (`assertConfigured`) | `503 LIVEKIT_NOT_CONFIGURED` |
| 13 | Service (`livekit.service.ts:309`) | LiveKit SFU room lazily provisioned & reachable (`ensureRoomExists`) | `503 LIVEKIT_UNAVAILABLE` |
| 14 | Service (`meeting.service.ts:1829`) | **Post-generation TOCTOU re-check:** re-reads MongoDB to confirm meeting not `ENDED`/`EXPIRED`, participant still `ADMITTED`, and `tokenEpoch` unchanged | `410 LIVEKIT_MEETING_ENDED` / `403 PARTICIPANT_REMOVED` / `403 LIVEKIT_ACCESS_DENIED` |

*(Plus **5 Pre-Handshake Signaling Gateway Checks** in `livekitSignalGateway.ts` on every `/livekit-signal/rtc[/v1]` validate & WebSocket upgrade: JWT cryptographic signature/exp, opaque room/identity parsing, live Meeting status, live Participant `ADMITTED` status, and signed `tokenEpoch` + `tokenRevokedBefore` validation.)*

### 4.2 The 20 Tested Security, Forgery & Revocation Scenarios

| Scenario # | Attack / Edge Case | Gate Check(s) Exercised | Enforced Outcome | Verification Source |
| ---: | --- | --- | --- | --- |
| 1 | Unauthenticated token request | Check #1 | `401 UNAUTHORIZED` | `livekitTokenAuth.test.ts` Test 1 |
| 2 | Untrusted `Origin` CSRF request | Check #2 | `403 CSRF_INVALID_ORIGIN` | `livekitTokenAuth.test.ts` Test 1 |
| 3 | Invalid meeting code format | Check #6 | `400 INVALID_MEETING_CODE` | `livekitTokenAuth.test.ts` Test 1 |
| 4 | Non-existent meeting | Check #6 | `404 MEETING_NOT_FOUND` | `livekitTokenAuth.test.ts` Test 1 |
| 5 | Non-member / outsider token request | Check #8 | `403 LIVEKIT_ACCESS_DENIED` | `livekitTokenAuth.test.ts` Test 2 & `test-phase09-livekit-real.mjs` |
| 6 | Waiting-room participant token request | Check #10 | `403 LIVEKIT_ACCESS_DENIED` | `livekitTokenAuth.test.ts` Test 2 & `test-phase09-livekit-real.mjs` |
| 7 | Rejected participant token request | Check #10 | `403 LIVEKIT_ACCESS_DENIED` | `livekitTokenAuth.test.ts` Test 2 |
| 8 | Removed participant new token request | Check #9 | `403 PARTICIPANT_REMOVED` | `livekitTokenAuth.test.ts` Test 2 & `test-phase09-livekit-real.mjs` |
| 9 | Left participant new token request | Check #10 | `403 LIVEKIT_ACCESS_DENIED` | `livekitTokenAuth.test.ts` Test 2 |
| 10 | Ended meeting token request | Check #7 | `410 LIVEKIT_MEETING_ENDED` | `livekitTokenAuth.test.ts` Test 4 & `test-phase09-livekit-real.mjs` |
| 11 | Locked meeting non-member token request | Check #8 | `403 MEETING_LOCKED` | `livekitTokenAuth.test.ts` Test 4 |
| 12 | Forged `identity`, `roomName`, `role`, or `canPublish` in request body | Check #4 | `400 VALIDATION_ERROR` | `livekitTokenAuth.test.ts` Test 1 |
| 13 | Removed participant original unexpired JWT reuse (same browser, fresh browser, offline-removed) via Gateway | Gateway Checks + `tokenEpoch` | **HTTP `403 PARTICIPANT_REMOVED`** pre-upgrade; Host uninterrupted | `livekitTokenAuth.test.ts` Test 7 & `test-phase09-token-reuse-audit.mjs` (6/6 PASS) |
| 14 | Pre-departure unexpired JWT reuse after `leaveMeeting` + legitimate rejoin | Gateway `tokenEpoch` Check | **HTTP `403 LIVEKIT_TOKEN_REVOKED`** | `livekitTokenAuth.test.ts` Test 8 |
| 15 | Concurrent token requests for same & distinct users | Checks #1–#14 | Clean parallel signing, zero corruption | `livekitTokenAuth.test.ts` Test 5 |
| 16 | Meeting terminated concurrently during token generation | Check #14 (barrier) | `410 LIVEKIT_MEETING_ENDED` (token discarded) | `livekitTokenAuth.test.ts` Test 5 |
| 17 | Participant removed concurrently during in-flight token generation | Check #14 (barrier) | `403 PARTICIPANT_REMOVED` (token discarded) | `livekitTokenAuth.test.ts` Test 8 |
| 18 | LiveKit configuration missing | Check #12 | `503 LIVEKIT_NOT_CONFIGURED` | `livekitService.test.ts` Test 4 & `livekitTokenAuth.test.ts` Test 6 |
| 19 | LiveKit server unavailable | Check #13 | `503 LIVEKIT_UNAVAILABLE` + honest `Connection failed` UI | `livekitService.test.ts` Test 5 & `verify_phase_09_unavailable.js` |
| 20 | Invalid/expired JWT or gateway `403` revoked rejection in client | Gateway + `livekitClient.ts` | Classified to `LIVEKIT_INVALID_TOKEN` / terminal `unauthorized` (`PARTICIPANT_REMOVED`) | `livekitClient.test.ts` Tests 3 & 6 |

*(Note: Rate limiter Check #3 is implemented via `livekitTokenLimiter` at `60 req / 5 min / IP` in `server/src/middlewares/rateLimiter.ts` and mounted on `meetings.routes.ts`.)*

---

## 5. Transport Encryption vs. End-to-End Encryption & Dependency Audit

- **Transport Encryption Only in Phase 09:** WebSocket signaling uses TLS (`wss://` in production) and WebRTC peer transport uses DTLS/SRTP. True **End-to-End Encryption (E2EE / SFrame)** is NOT implemented in Phase 09 and remains strictly scoped to **Phase 15**.
- **Production Dependency Audit (`npm audit --omit=dev`):**
  - `livekit-server-sdk@2.20.0`: **0 vulnerabilities**.
  - `livekit-client@2.24.1`: **0 vulnerabilities**.
  - `zod@4.6.7`: Patched and verified intact (`zodSecurity.test.ts` 6/6 PASS).
  - **2 pre-existing moderate advisories** remain disclosed in `react-router` v6 (`GHSA-wrjc-x8rr-h8h6` mitigated via `sanitizeRedirectPath`, and `GHSA-337j-9hxr-rhxg` SSR hydration unused by SPA).
