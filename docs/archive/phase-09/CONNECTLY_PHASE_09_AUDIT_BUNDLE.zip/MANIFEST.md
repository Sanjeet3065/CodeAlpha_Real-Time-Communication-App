# CONNECTLY — Phase 09 Audit Bundle Manifest

**Export Timestamp:** 2026-11-18T09:38:02+05:30
**Bundle Name:** `CONNECTLY_PHASE_09_AUDIT_BUNDLE.zip`
**Export Mode:** Read-only exact copy (no repository source files were modified, formatted, renamed, or altered).

---

## Exported & Missing File Inventory (9 Requested Files)

| File Name | Original Repository-Relative Path | File Type | Export Status | Integrity Confirmation | Redactions |
| --- | --- | --- | --- | --- | --- |
| livekitSignalGateway.ts | `server/src/realtime/livekitSignalGateway.ts` | TypeScript source (.ts) | Found & Exported | Exact match (byte-for-byte SHA-256 verified, 46086 bytes, `6129B36FD38351F7EB7809C7415507305E4C46DFF3924BF6FE139759789057DE`) | None |
| livekitRevocationCoordinator.ts | `server/src/realtime/livekitRevocationCoordinator.ts` | TypeScript source (.ts) | Found & Exported | Exact match (byte-for-byte SHA-256 verified, 18085 bytes, `8B969F96CBC83EAE30ADD7389ABAB468E8F4FF78D4436F6CAF257F57B4BFF602`) | None |
| LiveKitRevocationEvent.model.ts | `server/src/models/LiveKitRevocationEvent.model.ts` | TypeScript Mongoose model (.ts) | Found & Exported | Exact match (byte-for-byte SHA-256 verified, 3000 bytes, `2CD46EA622A2CBC5B28622E3657D4D0109BDBC63737D7369900EDAA6AA7EF4FF`) | None |
| LiveKitRevocationCounter.model.ts | *(Not present in repository)* | TypeScript Mongoose model (.ts) | **MISSING** | File does not exist as a standalone file in the repository (not fabricated or substituted). Note: `LiveKitRevocationCounter` is defined inside `server/src/models/LiveKitRevocationEvent.model.ts`. | N/A |
| livekit.service.ts | `server/src/services/livekit.service.ts` | TypeScript service (.ts) | Found & Exported | Exact match (byte-for-byte SHA-256 verified, 20975 bytes, `4D1CE1831E357B6F708C4E4F85F4374979327D0483C09787277E84071BA1CAB5`) | None |
| MeetingParticipant.model.ts | `server/src/models/MeetingParticipant.model.ts` | TypeScript Mongoose model (.ts) | Found & Exported | Exact match (byte-for-byte SHA-256 verified, 3616 bytes, `BE9D275117369586AD0912BB13F1D12652841ED21A095B1BDB7D58D83C0D0F57`) | None |
| livekitPostSyncFencing.test.ts | `server/src/tests/livekitPostSyncFencing.test.ts` | TypeScript test suite (.test.ts) | Found & Exported | Exact match (byte-for-byte SHA-256 verified, 23960 bytes, `4B3085DE0A83422E125922ABC51D48BC01B548ABE684D421E44DEB847D006A08`) | None |
| livekitCrossInstanceRevocation.test.ts | `server/src/tests/livekitCrossInstanceRevocation.test.ts` | TypeScript test suite (.test.ts) | Found & Exported | Exact match (byte-for-byte SHA-256 verified, 24896 bytes, `CF2CC6E33A9A259ED2FF19087ABB980F38A5FB522A88AD019E4D0D30256DA8AB`) | None |
| PHASE_09_SECURITY_AUDIT.md | `docs/PHASE_09_SECURITY_AUDIT.md` | Markdown security audit report (.md) | Found & Exported | Exact match (byte-for-byte SHA-256 verified, 26654 bytes, `8A4202FB3CA32CC78B301FD83787146D479037355305952DFE750BB9878F697B`) | None |

---

## Security & Privacy Verification

- **Secrets Excluded:** No `.env` files, production API keys, live access tokens, private certificates, or database credentials are included in this archive.
- **Redactions Required:** **0** files required redaction. The two test suites (`livekitPostSyncFencing.test.ts` and `livekitCrossInstanceRevocation.test.ts`) contain only synthetic, non-production unit-test fixture constants (`TEST_API_KEY`, `TEST_API_SECRET`, and synthetic test user password hashes).
- **Exact Repository Match:** All 8 exported files were verified byte-for-byte via SHA-256 checksums against the current repository versions immediately prior to archiving.