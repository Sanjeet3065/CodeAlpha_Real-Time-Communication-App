import { Types } from 'mongoose';
import {
  allocateNextRevocationSeq,
  LiveKitRevocationEvent,
  type LiveKitRevocationKind,
} from '../models/LiveKitRevocationEvent.model.js';
import { logger } from '../utils/logger.js';

export interface DistributedRevocationPayload {
  eventId: string;
  seq: number;
  meetingId: string;
  userId: string | null;
  kind: LiveKitRevocationKind;
  revokedEpoch: number | null;
  fenceVersion: number | null;
  reason: string | null;
  createdAt: Date;
}

export type RevocationListener = (event: DistributedRevocationPayload) => void;
export type RevocationHealthListener = (healthy: boolean, reason?: string) => void;

export interface LiveKitRevocationCoordinatorOptions {
  /** Poll interval (ms) for durable cursor catch-up / standalone MongoDB fallback. */
  pollIntervalMs?: number;
  /** Attempt to attach a MongoDB Change Stream (requires Replica Set in production). */
  enableChangeStream?: boolean;
  /** Consecutive DB poll failures before transitioning to fail-closed unhealthy state. */
  maxConsecutiveFailures?: number;
  /**
   * Maximum elapsed ms without a successful delivery sync before marking
   * the coordinator stalled/unhealthy (fail-closed).
   */
  maxStaleDeliveryMs?: number;
  /** Grace period (ms) to wait for an in-flight out-of-order lower `seq` before advancing past an aborted gap. */
  gapSkipGraceMs?: number;
  /** Optional initial durable cursor `seq` (for deterministic restart/recovery tests). */
  initialCursorSeq?: number;
}

/**
 * Publishes an authoritative, durable cross-instance revocation event into MongoDB
 * with a globally monotonic, clock-skew-independent `seq` allocated atomically.
 */
export async function publishLiveKitRevocation(params: {
  meetingId: string;
  userId?: string | null;
  kind: LiveKitRevocationKind;
  revokedEpoch?: number | null;
  fenceVersion?: number | null;
  reason?: string | null;
}): Promise<DistributedRevocationPayload> {
  const seq = await allocateNextRevocationSeq();
  const doc = await LiveKitRevocationEvent.create({
    seq,
    meetingId: new Types.ObjectId(params.meetingId),
    userId: params.userId ? new Types.ObjectId(params.userId) : null,
    kind: params.kind,
    revokedEpoch: params.revokedEpoch ?? null,
    fenceVersion: params.fenceVersion ?? null,
    reason: params.reason ?? null,
    createdAt: new Date(),
  });

  return {
    eventId: doc._id.toString(),
    seq: doc.seq,
    meetingId: doc.meetingId.toString(),
    userId: doc.userId ? doc.userId.toString() : null,
    kind: doc.kind,
    revokedEpoch: doc.revokedEpoch ?? null,
    fenceVersion: doc.fenceVersion ?? null,
    reason: doc.reason ?? null,
    createdAt: doc.createdAt,
  };
}

/**
 * Distributed cross-instance revocation coordinator backed by MongoDB.
 *
 * Guarantees & Properties:
 * - Global Monotonic Cursor (`seq`): Immune to cross-host ObjectId clock skew.
 * - Zero Skipped Events: `lastContiguousSeq` advances only across contiguous `seq`
 *   values (holding a bounded grace window for in-flight out-of-order commits while
 *   still dispatching newly observed higher-`seq` events immediately).
 * - Deduplication & Out-of-Order Safety: Duplicate events are dropped via `dispatchedSeqs`;
 *   out-of-order events are delivered safely without advancing past missing lower `seq`s.
 * - Change Stream Resume & Fallback: Captures `resumeAfter` tokens on Replica Sets,
 *   reconnects with `resumeAfter`, and executes immediate durable cursor catch-up on error.
 * - TTL Retention Guard: 24-hour event TTL (24x max 1-hour JWT TTL) plus explicit
 *   retention-gap detection (`oldestAvailableSeq > lastContiguousSeq + 1` -> fail-closed).
 * - Stalled Delivery Detection: `isHealthy()` checks both DB failure count AND
 *   `Date.now() - lastSuccessfulSyncAt > maxStaleDeliveryMs` so stalled delivery
 *   triggers fail-closed protection even when no DB exception is thrown.
 */
export class LiveKitRevocationCoordinator {
  private readonly pollIntervalMs: number;
  private readonly enableChangeStream: boolean;
  private readonly maxConsecutiveFailures: number;
  private readonly maxStaleDeliveryMs: number;
  private readonly gapSkipGraceMs: number;
  private readonly initialCursorSeq?: number;

  private readonly eventListeners = new Set<RevocationListener>();
  private readonly healthListeners = new Set<RevocationHealthListener>();

  private running = false;
  private healthy = true;
  private deliveryPaused = false;
  private unavailableReason: string | null = null;
  private transportMode: 'stopped' | 'change_stream' | 'cursor_poll' = 'stopped';
  private consecutiveFailures = 0;
  private lastSuccessfulSyncAt = Date.now();

  private lastContiguousSeq = 0;
  private readonly dispatchedSeqs = new Set<number>();
  private readonly gapFirstSeenAt = new Map<number, number>();
  private lastResumeToken: unknown = null;

  private pollTimer: ReturnType<typeof setInterval> | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private changeStream: { close: () => Promise<void> } | null = null;
  private inflightSync: Promise<boolean> | null = null;

  constructor(options: LiveKitRevocationCoordinatorOptions = {}) {
    this.pollIntervalMs = options.pollIntervalMs ?? 250;
    this.enableChangeStream = options.enableChangeStream ?? true;
    this.maxConsecutiveFailures = options.maxConsecutiveFailures ?? 2;
    this.maxStaleDeliveryMs =
      options.maxStaleDeliveryMs ?? Math.max(5_000, this.pollIntervalMs * 10);
    this.gapSkipGraceMs = options.gapSkipGraceMs ?? 5_000;
    this.initialCursorSeq = options.initialCursorSeq;
    if (typeof options.initialCursorSeq === 'number' && options.initialCursorSeq >= 0) {
      this.lastContiguousSeq = options.initialCursorSeq;
    }
  }

  public isRunning(): boolean {
    return this.running;
  }

  public getLastContiguousSeq(): number {
    return this.lastContiguousSeq;
  }

  public getTransportMode(): 'stopped' | 'change_stream' | 'cursor_poll' {
    return this.transportMode;
  }

  public getUnavailableReason(): string | null {
    return this.unavailableReason;
  }

  public getLastResumeToken(): unknown {
    return this.lastResumeToken;
  }

  /**
   * Checks BOTH explicit health state AND delivery-staleness watchdog.
   * If running and delivery has stalled beyond `maxStaleDeliveryMs`, transitions
   * immediately to UNHEALTHY (fail-closed) and notifies subscribed gateways.
   */
  public isHealthy(): boolean {
    if (!this.healthy) return false;
    if (this.running && Date.now() - this.lastSuccessfulSyncAt > this.maxStaleDeliveryMs) {
      this.setHealth(false, 'Revocation delivery stalled beyond staleness threshold.');
      return false;
    }
    return true;
  }

  public subscribe(listener: RevocationListener): () => void {
    this.eventListeners.add(listener);
    return () => {
      this.eventListeners.delete(listener);
    };
  }

  public onHealthChange(listener: RevocationHealthListener): () => void {
    this.healthListeners.add(listener);
    return () => {
      this.healthListeners.delete(listener);
    };
  }

  /**
   * Pauses background notification delivery (used by deterministic security tests
   * to simulate delayed cross-instance revocation delivery without arbitrary sleeps).
   */
  public pauseDelivery(): void {
    this.deliveryPaused = true;
  }

  public resumeDelivery(): void {
    this.deliveryPaused = false;
  }

  private setHealth(nextHealthy: boolean, reason?: string): void {
    const prev = this.healthy;
    this.healthy = nextHealthy;
    this.unavailableReason = nextHealthy ? null : reason || 'Revocation coordinator unavailable.';
    if (prev !== nextHealthy) {
      if (!nextHealthy) {
        logger.error('[LiveKitRevocation] Coordinator transitioned to UNHEALTHY (fail-closed)', {
          reason: this.unavailableReason,
        });
      } else {
        logger.info('[LiveKitRevocation] Coordinator recovered to HEALTHY');
      }
      for (const listener of Array.from(this.healthListeners)) {
        try {
          listener(nextHealthy, this.unavailableReason ?? undefined);
        } catch {
          // isolate subscriber errors
        }
      }
    }
  }

  public markUnavailable(reason = 'Revocation notification channel disconnected.'): void {
    this.setHealth(false, reason);
  }

  /**
   * Manually forces a staleness timestamp for deterministic watchdog tests.
   */
  public setLastSuccessfulSyncAtForTest(timestampMs: number): void {
    this.lastSuccessfulSyncAt = timestampMs;
  }

  /**
   * Delivers a single revocation event with exact deduplication and monotonic
   * contiguous-sequence tracking (safe against duplicate and out-of-order arrival).
   */
  public ingestEvent(payload: DistributedRevocationPayload): boolean {
    if (this.dispatchedSeqs.has(payload.seq)) {
      return false;
    }
    this.dispatchedSeqs.add(payload.seq);
    this.gapFirstSeenAt.delete(payload.seq);

    // Advance contiguous cursor strictly across consecutive observed sequences
    while (this.dispatchedSeqs.has(this.lastContiguousSeq + 1)) {
      this.lastContiguousSeq += 1;
    }

    // Bound memory of dispatchedSeqs by pruning entries strictly behind lastContiguousSeq
    if (this.dispatchedSeqs.size > 4000) {
      for (const s of Array.from(this.dispatchedSeqs)) {
        if (s <= this.lastContiguousSeq) {
          this.dispatchedSeqs.delete(s);
        }
      }
    }

    for (const listener of Array.from(this.eventListeners)) {
      try {
        listener(payload);
      } catch (err) {
        logger.error('[LiveKitRevocation] Listener error while applying revocation', {
          eventId: payload.eventId,
          seq: payload.seq,
          message: err instanceof Error ? err.message : 'Unknown listener error',
        });
      }
    }
    return true;
  }

  private advanceExpiredGaps(maxObservedSeq: number): void {
    const now = Date.now();
    for (let missing = this.lastContiguousSeq + 1; missing < maxObservedSeq; missing += 1) {
      if (this.dispatchedSeqs.has(missing)) continue;
      const firstSeen = this.gapFirstSeenAt.get(missing);
      if (firstSeen === undefined) {
        this.gapFirstSeenAt.set(missing, now);
      } else if (now - firstSeen >= this.gapSkipGraceMs) {
        // Gap exceeded in-flight commit grace period (aborted counter allocation); advance past it
        this.gapFirstSeenAt.delete(missing);
        this.dispatchedSeqs.add(missing);
      }
    }
    while (this.dispatchedSeqs.has(this.lastContiguousSeq + 1)) {
      this.lastContiguousSeq += 1;
    }
  }

  public async start(): Promise<void> {
    if (this.running) return;
    this.running = true;
    this.consecutiveFailures = 0;

    try {
      if (typeof this.initialCursorSeq === 'number' && this.initialCursorSeq >= 0) {
        this.lastContiguousSeq = this.initialCursorSeq;
      } else {
        const latest = await LiveKitRevocationEvent.findOne({})
          .sort({ seq: -1 })
          .select('seq')
          .lean();
        this.lastContiguousSeq = latest && typeof latest.seq === 'number' ? latest.seq : 0;
      }
      this.lastSuccessfulSyncAt = Date.now();
      this.setHealth(true);
    } catch (err) {
      this.setHealth(
        false,
        err instanceof Error ? err.message : 'Unable to initialize revocation cursor.'
      );
    }

    if (this.enableChangeStream) {
      await this.tryAttachChangeStream();
    } else {
      this.transportMode = 'cursor_poll';
    }

    this.pollTimer = setInterval(() => {
      if (this.deliveryPaused) {
        // Still run staleness watchdog while delivery is paused
        this.isHealthy();
        return;
      }
      void this.syncNow();
    }, this.pollIntervalMs);
    if (typeof this.pollTimer.unref === 'function') {
      this.pollTimer.unref();
    }
  }

  private async tryAttachChangeStream(): Promise<void> {
    try {
      const db = LiveKitRevocationEvent.db;
      const admin = db?.db?.admin();
      if (admin) {
        const hello = await admin.command({ hello: 1 });
        if (!hello?.setName) {
          this.transportMode = 'cursor_poll';
          return;
        }
      }

      const watchOpts: Record<string, unknown> = { fullDocument: 'updateLookup' };
      if (this.lastResumeToken) {
        watchOpts.resumeAfter = this.lastResumeToken;
      }

      const stream = LiveKitRevocationEvent.watch(
        [{ $match: { operationType: 'insert' } }],
        watchOpts
      );

      stream.on('change', (change: any) => {
        if (change?._id) {
          this.lastResumeToken = change._id;
        }
        if (this.deliveryPaused) return;
        const doc = change?.fullDocument;
        if (!doc || !doc._id || !doc.meetingId || !doc.kind || typeof doc.seq !== 'number') return;
        this.consecutiveFailures = 0;
        this.lastSuccessfulSyncAt = Date.now();
        this.setHealth(true);
        this.ingestEvent({
          eventId: String(doc._id),
          seq: doc.seq,
          meetingId: String(doc.meetingId),
          userId: doc.userId ? String(doc.userId) : null,
          kind: doc.kind,
          revokedEpoch: typeof doc.revokedEpoch === 'number' ? doc.revokedEpoch : null,
          fenceVersion: typeof doc.fenceVersion === 'number' ? doc.fenceVersion : null,
          reason: typeof doc.reason === 'string' ? doc.reason : null,
          createdAt: doc.createdAt ? new Date(doc.createdAt) : new Date(),
        });
      });

      stream.on('error', (err: any) => {
        logger.warn(
          '[LiveKitRevocation] Change stream interrupted; running durable cursor catch-up and scheduling resume',
          {
            message: err instanceof Error ? err.message : String(err || 'Change stream error'),
          }
        );
        this.transportMode = 'cursor_poll';
        this.changeStream = null;
        if (!this.deliveryPaused) {
          void this.syncNow();
        }
        if (this.running && !this.reconnectTimer) {
          this.reconnectTimer = setTimeout(() => {
            this.reconnectTimer = null;
            if (this.running) {
              void this.tryAttachChangeStream();
            }
          }, 1_000);
          if (typeof this.reconnectTimer.unref === 'function') {
            this.reconnectTimer.unref();
          }
        }
      });

      this.changeStream = stream;
      this.transportMode = 'change_stream';
    } catch {
      this.transportMode = 'cursor_poll';
      this.changeStream = null;
    }
  }

  /**
   * Synchronously sweeps all durable `LiveKitRevocationEvent` records with
   * `seq > lastContiguousSeq`, checks TTL retention continuity (fail-closed if
   * undelivered events expired during an extended outage), and dispatches events
   * in exact sequence order.
   */
  public async syncNow(): Promise<boolean> {
    if (this.inflightSync) {
      return this.inflightSync;
    }

    const run = async (): Promise<boolean> => {
      try {
        const events = await LiveKitRevocationEvent.find({
          seq: { $gt: this.lastContiguousSeq },
        })
          .sort({ seq: 1 })
          .limit(500)
          .lean();

        this.consecutiveFailures = 0;
        this.lastSuccessfulSyncAt = Date.now();

        if (events.length > 0) {
          // Retention discontinuity guard: if the oldest event in DB is strictly
          // older than expected AND created before our retention window, detect
          // potential TTL expiry of an undelivered event and fail closed.
          const firstSeq = events[0].seq;
          if (
            this.lastContiguousSeq > 0 &&
            firstSeq > this.lastContiguousSeq + 1 &&
            Date.now() - new Date(events[0].createdAt).getTime() > this.gapSkipGraceMs * 4
          ) {
            this.setHealth(
              false,
              `Revocation cursor discontinuity detected (expected seq ${this.lastContiguousSeq + 1}, oldest available ${firstSeq}); failing closed.`
            );
            return false;
          }

          let maxObservedSeq = this.lastContiguousSeq;
          for (const doc of events) {
            if (typeof doc.seq !== 'number') continue;
            if (doc.seq > maxObservedSeq) maxObservedSeq = doc.seq;
            this.ingestEvent({
              eventId: String(doc._id),
              seq: doc.seq,
              meetingId: String(doc.meetingId),
              userId: doc.userId ? String(doc.userId) : null,
              kind: doc.kind,
              revokedEpoch: typeof doc.revokedEpoch === 'number' ? doc.revokedEpoch : null,
              fenceVersion: typeof doc.fenceVersion === 'number' ? doc.fenceVersion : null,
              reason: typeof doc.reason === 'string' ? doc.reason : null,
              createdAt: doc.createdAt ? new Date(doc.createdAt) : new Date(),
            });
          }
          this.advanceExpiredGaps(maxObservedSeq);
        }

        if (this.running) {
          this.setHealth(true);
        }
        return true;
      } catch (err) {
        this.consecutiveFailures += 1;
        if (this.consecutiveFailures >= this.maxConsecutiveFailures) {
          this.setHealth(
            false,
            err instanceof Error ? err.message : 'Revocation cursor sync failed.'
          );
        }
        return false;
      }
    };

    this.inflightSync = run().finally(() => {
      this.inflightSync = null;
    });
    return this.inflightSync;
  }

  public async stop(): Promise<void> {
    this.running = false;
    this.deliveryPaused = false;
    this.transportMode = 'stopped';
    if (this.pollTimer) {
      clearInterval(this.pollTimer);
      this.pollTimer = null;
    }
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.changeStream) {
      const stream = this.changeStream;
      this.changeStream = null;
      await stream.close().catch(() => {});
    }
    this.eventListeners.clear();
    this.healthListeners.clear();
  }
}

export const livekitRevocationCoordinator = new LiveKitRevocationCoordinator();
